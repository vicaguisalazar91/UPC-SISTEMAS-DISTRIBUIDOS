﻿Public Class frmMntFederaciones
    'Instanciamos dataTable
    Private dtFederacion As New dsOlympics.FederationDataTable
    'Levantar instancia del tableAdapter
    Private taFederacion As New dsOlympicsTableAdapters.FederationTableAdapter
    'Levantar instancia de una fila del tableAdapter
    Private regFederacion As dsOlympics.FederationRow

    'Es para efrectos de la logica del aplicativo
    Private campoLLave As String
    Private editar As Boolean = False
    Private numeroRegistro As String

    Private Sub CabeceraGrilla()
        dgFederacion.Columns(0).Width = 40
        dgFederacion.Columns(1).Width = 260
        dgFederacion.Columns(2).Width = 130
        dgFederacion.Columns(0).HeaderText = "ID"
        dgFederacion.Columns(1).HeaderText = "Nombre de Federación"
        dgFederacion.Columns(2).HeaderText = "Cant. Federados"
    End Sub

    Private Sub frmMntFederaciones_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.dtFederacion = Me.taFederacion.GetData()
        dgFederacion.DataSource = Me.dtFederacion

        CabeceraGrilla()
    End Sub

    Private Sub GuardarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GuardarToolStripMenuItem.Click

        If (Me.editar) Then
            regFederacion = dtFederacion.FindByFederationID(Me.campoLLave)
            regFederacion.FederationName = txtNomFed.Text

            'Actualizamos la Base de datos original
            Try
                taFederacion.Update(dtFederacion)
                MsgBox("Actualización exitosa")
            Catch ex As Exception
                MsgBox("Actualización fallida ....:(")
            End Try
            Me.editar = False
            Me.limpiarCajasTexto()
        Else
            'código para insertar un nuevo registro
            Me.regFederacion = dtFederacion.NewFederationRow
            Me.regFederacion.FederationID = txtCodFed.Text
            Me.regFederacion.FederationName = txtNomFed.Text
            'agregar registro al datatable
            dtFederacion.AddFederationRow(Me.regFederacion)
            'actualizamos la base de datos
            Try
                taFederacion.Update(dtFederacion)
                MsgBox("Registro insertado exitosamente")
            Catch ex As Exception
                MsgBox("Error al insertar un registro ...")
            End Try
            Me.limpiarCajasTexto()
        End If
    End Sub

    Private Sub ActualizarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ActualizarToolStripMenuItem.Click
        Me.editar = True
        cargarDatosEnCajasTexto()
    End Sub

    Private Sub cargarDatosEnCajasTexto()
        Me.campoLLave = dgFederacion.CurrentRow.Cells(0).Value.ToString
        txtNomFed.Text = dgFederacion.CurrentRow.Cells(1).Value.ToString
    End Sub

    Private Sub limpiarCajasTexto()
        txtCodFed.Text = ""
        txtNomFed.Text = ""
    End Sub

    Private Sub EliminarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EliminarToolStripMenuItem.Click
        Me.regFederacion = dtFederacion.Rows(Me.numeroRegistro)
        Try
            regFederacion.Delete()
            taFederacion.Update(dtFederacion)
            MsgBox("Registro borrado Exitosamente")
        Catch ex As Exception
            MsgBox("No se pudo eliminar el registro")
        End Try
        
    End Sub

    Private Sub dgFederacion_SelectionChanged(sender As Object, e As EventArgs) Handles dgFederacion.SelectionChanged
        lblNumRegistro.Text = dgFederacion.CurrentRow.Index.ToString()
        Me.numeroRegistro = dgFederacion.CurrentRow.Index.ToString()
    End Sub

    Private Sub txtVerTodos_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtBuscarFederacion.KeyPress
        'Primero lleno mi dataTable
        dtFederacion = taFederacion.GetDataByNombreFederacion(txtBuscarFederacion.Text)
        'Asignar al datagrid el datatTable Lleno
        dgFederacion.DataSource = dtFederacion

    End Sub

    Private Sub btnVerTodos_Click(sender As Object, e As EventArgs) Handles btnVerTodos.Click
        Me.dtFederacion = Me.taFederacion.GetData()
        dgFederacion.DataSource = Me.dtFederacion
    End Sub

    Private Sub dgFederacion_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgFederacion.CellContentClick

    End Sub
End Class