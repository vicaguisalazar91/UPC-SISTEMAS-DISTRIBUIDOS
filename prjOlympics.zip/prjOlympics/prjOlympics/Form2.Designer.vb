﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMntFederaciones
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.GuardarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActualizarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EliminarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.dgFederacion = New System.Windows.Forms.DataGridView()
        Me.lblNumRegistro = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtNomFed = New System.Windows.Forms.TextBox()
        Me.txtCodFed = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtBuscarFederacion = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.FederationTableAdapter1 = New prjOlympics.dsOlympicsTableAdapters.FederationTableAdapter()
        Me.btnVerTodos = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.dgFederacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GuardarToolStripMenuItem, Me.ActualizarToolStripMenuItem, Me.EliminarToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(505, 26)
        Me.MenuStrip1.TabIndex = 8
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'GuardarToolStripMenuItem
        '
        Me.GuardarToolStripMenuItem.Name = "GuardarToolStripMenuItem"
        Me.GuardarToolStripMenuItem.Size = New System.Drawing.Size(72, 22)
        Me.GuardarToolStripMenuItem.Text = "Guardar"
        '
        'ActualizarToolStripMenuItem
        '
        Me.ActualizarToolStripMenuItem.Name = "ActualizarToolStripMenuItem"
        Me.ActualizarToolStripMenuItem.Size = New System.Drawing.Size(81, 22)
        Me.ActualizarToolStripMenuItem.Text = "Actualizar"
        '
        'EliminarToolStripMenuItem
        '
        Me.EliminarToolStripMenuItem.Name = "EliminarToolStripMenuItem"
        Me.EliminarToolStripMenuItem.Size = New System.Drawing.Size(68, 22)
        Me.EliminarToolStripMenuItem.Text = "Eliminar"
        '
        'dgFederacion
        '
        Me.dgFederacion.AllowUserToAddRows = False
        Me.dgFederacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Lime
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlDarkDark
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgFederacion.DefaultCellStyle = DataGridViewCellStyle1
        Me.dgFederacion.Location = New System.Drawing.Point(13, 193)
        Me.dgFederacion.Name = "dgFederacion"
        Me.dgFederacion.ReadOnly = True
        Me.dgFederacion.RowTemplate.Height = 24
        Me.dgFederacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgFederacion.Size = New System.Drawing.Size(481, 150)
        Me.dgFederacion.TabIndex = 9
        '
        'lblNumRegistro
        '
        Me.lblNumRegistro.AutoSize = True
        Me.lblNumRegistro.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNumRegistro.Location = New System.Drawing.Point(463, 149)
        Me.lblNumRegistro.Name = "lblNumRegistro"
        Me.lblNumRegistro.Size = New System.Drawing.Size(2, 19)
        Me.lblNumRegistro.TabIndex = 10
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtNomFed)
        Me.GroupBox1.Controls.Add(Me.txtCodFed)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 38)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(481, 97)
        Me.GroupBox1.TabIndex = 11
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Federaciones:"
        '
        'txtNomFed
        '
        Me.txtNomFed.Location = New System.Drawing.Point(80, 53)
        Me.txtNomFed.Name = "txtNomFed"
        Me.txtNomFed.Size = New System.Drawing.Size(388, 22)
        Me.txtNomFed.TabIndex = 9
        '
        'txtCodFed
        '
        Me.txtCodFed.Location = New System.Drawing.Point(80, 24)
        Me.txtCodFed.Name = "txtCodFed"
        Me.txtCodFed.Size = New System.Drawing.Size(100, 22)
        Me.txtCodFed.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 17)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Nombre:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 17)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Código:"
        '
        'txtBuscarFederacion
        '
        Me.txtBuscarFederacion.Location = New System.Drawing.Point(149, 146)
        Me.txtBuscarFederacion.Name = "txtBuscarFederacion"
        Me.txtBuscarFederacion.Size = New System.Drawing.Size(170, 22)
        Me.txtBuscarFederacion.TabIndex = 12
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 146)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(131, 17)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Buscar Federación:"
        '
        'FederationTableAdapter1
        '
        Me.FederationTableAdapter1.ClearBeforeFill = True
        '
        'btnVerTodos
        '
        Me.btnVerTodos.Location = New System.Drawing.Point(325, 149)
        Me.btnVerTodos.Name = "btnVerTodos"
        Me.btnVerTodos.Size = New System.Drawing.Size(110, 23)
        Me.btnVerTodos.TabIndex = 14
        Me.btnVerTodos.Text = "Ver todos"
        Me.btnVerTodos.UseVisualStyleBackColor = True
        '
        'frmMntFederaciones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(505, 358)
        Me.Controls.Add(Me.btnVerTodos)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtBuscarFederacion)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lblNumRegistro)
        Me.Controls.Add(Me.dgFederacion)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMntFederaciones"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Mantenimiento de Federaciones"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.dgFederacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents GuardarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ActualizarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EliminarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents dgFederacion As System.Windows.Forms.DataGridView
    Friend WithEvents FederationTableAdapter1 As prjOlympics.dsOlympicsTableAdapters.FederationTableAdapter
    Friend WithEvents lblNumRegistro As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtNomFed As System.Windows.Forms.TextBox
    Friend WithEvents txtCodFed As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtBuscarFederacion As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnVerTodos As System.Windows.Forms.Button
End Class
