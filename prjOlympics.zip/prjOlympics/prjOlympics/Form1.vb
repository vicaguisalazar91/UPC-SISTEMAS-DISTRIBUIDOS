﻿Public Class frmMenu
    Private Sub FederacionesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FederacionesToolStripMenuItem.Click
        frmMntFederaciones.Show()
    End Sub

    Private Sub EstacionesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EstacionesToolStripMenuItem.Click
        frmMntEstaciones.Show()
    End Sub

    Private Sub EsquiadoresToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EsquiadoresToolStripMenuItem.Click
        frmMntEsquiadores.Show()
    End Sub

    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        End
    End Sub

    Private Sub frmMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub
End Class
