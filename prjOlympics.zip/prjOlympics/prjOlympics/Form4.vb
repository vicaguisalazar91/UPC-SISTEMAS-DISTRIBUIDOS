﻿Public Class frmMntEsquiadores
    'Instanciamos dataTable
    Private dtFederacion As New dsOlympics.FederationDataTable
    Private taFederacion As New dsOlympicsTableAdapters.FederationTableAdapter
    Private regFederacion As dsOlympics.FederationRow

    'Instaciamos Esquiadores
    Private dtEsquiador As New dsOlympics.SkierDataTable
    Private taEsquiador As New dsOlympicsTableAdapters.SkierTableAdapter
    Private regEsquiador As dsOlympics.SkierRow

    'Es para efrectos de la logica del aplicativo
    Private campoLLave As String
    Private editar As Boolean = False
    Private numeroRegistro As String

    Private Sub frmMntEsquiador_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DsOlympics.Federation' table. You can move, or remove it, as needed.
        Me.FederationTableAdapter.Fill(Me.DsOlympics.Federation)
        Me.dtEsquiador = Me.taEsquiador.GetData()
        dgEsquiador.DataSource = Me.dtEsquiador
    End Sub

    Private Sub GuardarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GuardarToolStripMenuItem.Click
        If (Me.editar) Then
            regEsquiador = dtEsquiador.FindByNumberId(Me.campoLLave)
            regEsquiador.SkierName = txtNomEsqui.Text
            regEsquiador.Birthdate = dtpFecNacEsqui.Text
            regEsquiador.FederationID = cmbNomFed.ValueMember.ToString

            'Actualizamos la Base de datos original
            Try
                taEsquiador.Update(dtEsquiador)
                MsgBox("Actualización exitosa")
            Catch ex As Exception
                MsgBox("Actualización fallida ....:(")
            End Try
            Me.editar = False
            Me.limpiarCajasTexto()
        Else
            'código para insertar un nuevo registro
            Me.regFederacion = dtFederacion.NewFederationRow
            Me.regFederacion.FederationID = txtCodEsqui.Text
            Me.regFederacion.FederationName = txtNomEsqui.Text
            'agregar registro al datatable
            dtFederacion.AddFederationRow(Me.regFederacion)
            'actualizamos la base de datos
            Try
                taFederacion.Update(dtFederacion)
                MsgBox("Registro insertado exitosamente")
            Catch ex As Exception
                MsgBox("Error al insertar un registro ...")
            End Try
            Me.limpiarCajasTexto()
        End If

    End Sub

    Private Sub cargarDatosEnCajasTexto()
        Me.campoLLave = dgEsquiador.CurrentRow.Cells(0).Value.ToString
        txtNomEsqui.Text = dgEsquiador.CurrentRow.Cells(1).Value.ToString
        dtpFecNacEsqui.Text = dgEsquiador.CurrentRow.Cells(2).Value.ToString
        cmbNomFed.SelectedValue = dgEsquiador.CurrentRow.Cells(3).Value.ToString


    End Sub

    Private Sub limpiarCajasTexto()
        txtCodEsqui.Text = ""
        txtNomEsqui.Text = ""

    End Sub

    Private Sub dgEsquiador_SelectionChanged(sender As Object, e As EventArgs) Handles dgEsquiador.SelectionChanged
        lblNumRegistro.Text = dgEsquiador.CurrentRow.Index.ToString()
        Me.numeroRegistro = dgEsquiador.CurrentRow.Index.ToString()
    End Sub

    Private Sub dgEsquiador_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgEsquiador.CellContentClick

    End Sub

    Private Sub ActualizarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ActualizarToolStripMenuItem.Click
        Me.editar = True
        cargarDatosEnCajasTexto()
    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub
End Class