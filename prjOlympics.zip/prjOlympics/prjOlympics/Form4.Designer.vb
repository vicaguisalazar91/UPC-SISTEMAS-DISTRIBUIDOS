﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMntEsquiadores
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbNomFed = New System.Windows.Forms.ComboBox()
        Me.txtNomEsqui = New System.Windows.Forms.TextBox()
        Me.txtCodEsqui = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.GuardarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActualizarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EliminarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.dgEsquiador = New System.Windows.Forms.DataGridView()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtBuscaEsquiador = New System.Windows.Forms.TextBox()
        Me.lblNumRegistro = New System.Windows.Forms.Label()
        Me.btnVerTodos = New System.Windows.Forms.Button()
        Me.dtpFecNacEsqui = New System.Windows.Forms.DateTimePicker()
        Me.DsOlympics = New prjOlympics.dsOlympics()
        Me.FederationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.FederationTableAdapter = New prjOlympics.dsOlympicsTableAdapters.FederationTableAdapter()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.dgEsquiador, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsOlympics, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FederationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtpFecNacEsqui)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.cmbNomFed)
        Me.GroupBox1.Controls.Add(Me.txtNomEsqui)
        Me.GroupBox1.Controls.Add(Me.txtCodEsqui)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 34)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(462, 142)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Esquiadores:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(13, 106)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 17)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Federación:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(13, 78)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(145, 17)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Fecha de Nacimiento:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 17)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Nombre:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 17)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Código:"
        '
        'cmbNomFed
        '
        Me.cmbNomFed.DataSource = Me.FederationBindingSource
        Me.cmbNomFed.DisplayMember = "FederationName"
        Me.cmbNomFed.FormattingEnabled = True
        Me.cmbNomFed.Location = New System.Drawing.Point(161, 106)
        Me.cmbNomFed.Name = "cmbNomFed"
        Me.cmbNomFed.Size = New System.Drawing.Size(289, 24)
        Me.cmbNomFed.TabIndex = 11
        Me.cmbNomFed.ValueMember = "FederationID"
        '
        'txtNomEsqui
        '
        Me.txtNomEsqui.Location = New System.Drawing.Point(161, 50)
        Me.txtNomEsqui.Name = "txtNomEsqui"
        Me.txtNomEsqui.Size = New System.Drawing.Size(289, 22)
        Me.txtNomEsqui.TabIndex = 9
        '
        'txtCodEsqui
        '
        Me.txtCodEsqui.Location = New System.Drawing.Point(161, 22)
        Me.txtCodEsqui.Name = "txtCodEsqui"
        Me.txtCodEsqui.Size = New System.Drawing.Size(70, 22)
        Me.txtCodEsqui.TabIndex = 8
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GuardarToolStripMenuItem, Me.ActualizarToolStripMenuItem, Me.EliminarToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(488, 28)
        Me.MenuStrip1.TabIndex = 9
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'GuardarToolStripMenuItem
        '
        Me.GuardarToolStripMenuItem.Name = "GuardarToolStripMenuItem"
        Me.GuardarToolStripMenuItem.Size = New System.Drawing.Size(72, 22)
        Me.GuardarToolStripMenuItem.Text = "Guardar"
        '
        'ActualizarToolStripMenuItem
        '
        Me.ActualizarToolStripMenuItem.Name = "ActualizarToolStripMenuItem"
        Me.ActualizarToolStripMenuItem.Size = New System.Drawing.Size(81, 24)
        Me.ActualizarToolStripMenuItem.Text = "Actualizar"
        '
        'EliminarToolStripMenuItem
        '
        Me.EliminarToolStripMenuItem.Name = "EliminarToolStripMenuItem"
        Me.EliminarToolStripMenuItem.Size = New System.Drawing.Size(68, 22)
        Me.EliminarToolStripMenuItem.Text = "Eliminar"
        '
        'dgEsquiador
        '
        Me.dgEsquiador.AllowUserToAddRows = False
        Me.dgEsquiador.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgEsquiador.Location = New System.Drawing.Point(12, 223)
        Me.dgEsquiador.Name = "dgEsquiador"
        Me.dgEsquiador.ReadOnly = True
        Me.dgEsquiador.RowTemplate.Height = 24
        Me.dgEsquiador.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgEsquiador.Size = New System.Drawing.Size(462, 251)
        Me.dgEsquiador.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 183)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(124, 17)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Buscar Esquiador:"
        '
        'txtBuscaEsquiador
        '
        Me.txtBuscaEsquiador.Location = New System.Drawing.Point(145, 183)
        Me.txtBuscaEsquiador.Name = "txtBuscaEsquiador"
        Me.txtBuscaEsquiador.Size = New System.Drawing.Size(166, 22)
        Me.txtBuscaEsquiador.TabIndex = 12
        '
        'lblNumRegistro
        '
        Me.lblNumRegistro.AutoSize = True
        Me.lblNumRegistro.Location = New System.Drawing.Point(422, 187)
        Me.lblNumRegistro.Name = "lblNumRegistro"
        Me.lblNumRegistro.Size = New System.Drawing.Size(11, 17)
        Me.lblNumRegistro.TabIndex = 13
        Me.lblNumRegistro.Text = "|"
        '
        'btnVerTodos
        '
        Me.btnVerTodos.Location = New System.Drawing.Point(321, 183)
        Me.btnVerTodos.Name = "btnVerTodos"
        Me.btnVerTodos.Size = New System.Drawing.Size(95, 23)
        Me.btnVerTodos.TabIndex = 14
        Me.btnVerTodos.Text = "Ver Todos"
        Me.btnVerTodos.UseVisualStyleBackColor = True
        '
        'dtpFecNacEsqui
        '
        Me.dtpFecNacEsqui.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecNacEsqui.Location = New System.Drawing.Point(161, 78)
        Me.dtpFecNacEsqui.Name = "dtpFecNacEsqui"
        Me.dtpFecNacEsqui.Size = New System.Drawing.Size(105, 22)
        Me.dtpFecNacEsqui.TabIndex = 16
        Me.dtpFecNacEsqui.Value = New Date(2017, 12, 9, 0, 0, 0, 0)
        '
        'DsOlympics
        '
        Me.DsOlympics.DataSetName = "dsOlympics"
        Me.DsOlympics.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'FederationBindingSource
        '
        Me.FederationBindingSource.DataMember = "Federation"
        Me.FederationBindingSource.DataSource = Me.DsOlympics
        '
        'FederationTableAdapter
        '
        Me.FederationTableAdapter.ClearBeforeFill = True
        '
        'frmMntEsquiadores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(488, 486)
        Me.Controls.Add(Me.btnVerTodos)
        Me.Controls.Add(Me.lblNumRegistro)
        Me.Controls.Add(Me.txtBuscaEsquiador)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.dgEsquiador)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMntEsquiadores"
        Me.Text = "Mantenimiento de Esquiadores"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.dgEsquiador, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsOlympics, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FederationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbNomFed As System.Windows.Forms.ComboBox
    Friend WithEvents txtNomEsqui As System.Windows.Forms.TextBox
    Friend WithEvents txtCodEsqui As System.Windows.Forms.TextBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents GuardarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ActualizarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EliminarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents dgEsquiador As System.Windows.Forms.DataGridView
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtBuscaEsquiador As System.Windows.Forms.TextBox
    Friend WithEvents lblNumRegistro As System.Windows.Forms.Label
    Friend WithEvents btnVerTodos As System.Windows.Forms.Button
    Friend WithEvents dtpFecNacEsqui As System.Windows.Forms.DateTimePicker
    Friend WithEvents DsOlympics As prjOlympics.dsOlympics
    Friend WithEvents FederationBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents FederationTableAdapter As prjOlympics.dsOlympicsTableAdapters.FederationTableAdapter
End Class
