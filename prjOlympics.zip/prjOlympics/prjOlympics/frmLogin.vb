﻿Public Class frmLogin
    Private dtUsuarios As New Login.UserDataTable
    Private taUsuarios As New LoginTableAdapters.UserTableAdapter
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles txtIngresar.Click
        dtUsuarios = taUsuarios.GetDataAccesoUsuario(txtUsuario.Text, txtPassword.Text)
        If dtUsuarios.Count > 0 Then 'Si la dataTable contiene un registro
            MsgBox("Bienvenido al sistema :) ...! ")
            'Oculto el formulario actual
            Me.Hide()
            frmMenu.Show()
        Else
            MsgBox("Acceso Incorrecto ..!!")
        End If
    End Sub
End Class